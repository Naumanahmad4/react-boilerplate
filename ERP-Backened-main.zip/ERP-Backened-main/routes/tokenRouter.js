const express = require('express');
const tokenRouter = express.Router();
// const userController = require('../controllers/users')
// const courseController = require('../controllers/course')
// const classController = require('../controllers/classes')

// tokenRouter.route('/addUser').post(userController.addUser)
// tokenRouter.route('/checkUserName').post(userController.checkUserName)
// tokenRouter.route('/getAllTeacher').get(userController.getAllTeacher)
// tokenRouter.route('/getAllStudent').get(userController.getAllStudent)


// tokenRouter.route('/getSearchTeacher').post(userController.getSearchTeacher)
// tokenRouter.route('/getSearchStudent').post(userController.getSearchStudent)



// tokenRouter.route('/addCourse').post(courseController.addCourse)
// tokenRouter.route('/getAllCourse').get(courseController.getAllCourse)
// tokenRouter.route('/getSearchCourse').post(courseController.getSearchCourse)


// tokenRouter.route('/addClasses').post(classController.addClasses)
// tokenRouter.route('/getAllClasses').get(classController.getAllClasses)

module.exports = tokenRouter;